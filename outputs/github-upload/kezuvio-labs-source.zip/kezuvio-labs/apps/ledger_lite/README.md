# Ledger Lite

Independent Flutter cash-flow development app. Use Flutter 3.47.5. From this folder run flutter pub get, flutter gen-l10n, then flutter run --flavor dev.

Development APK: flutter build apk --debug --flavor dev. Release signing is not configured and release builds are blocked. See the root README for source-package scope. Tests, local databases, SDKs and signing keys are not included.
