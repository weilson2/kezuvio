# Kezuvio Labs

Source-only GitHub package: the studio website, six shared web products, five legacy web demos, and the independent Ledger Lite Flutter application.

## Included projects

| Project | Source |
| --- | --- |
| Studio website | apps/website |
| Cafe POS and QR Ordering | packages/cafe; /demo/cafe-pos |
| Commerce Studio | packages/commerce; /demo/commerce-studio |
| AI Automation Hub | packages/automation; /demo/automation-hub |
| Property CRM | packages/property; /demo/property-crm |
| Accounting Cloud | packages/accounting; /demo/accounting-cloud |
| Interior 3D Studio | packages/interior; /demo/interior-3d |
| Ledger Lite | apps/ledger_lite |

The web products run in one Next.js application and depend on the shared packages. Upload this entire folder as one repository. Ledger Lite has its own Flutter toolchain and does not use the web database.

## Website

Use Node.js 24 and npm. From this repository root:

~~~sh
npm ci
npm run build
npm run start
~~~

Open http://127.0.0.1:3000 or /demo. For development use npm run dev. Copy .env.example to apps/website/.env.local for optional contact links, canonical URL and origin settings. Dependency installation, Prisma generation and brand generation are required; node_modules and generated builds are intentionally excluded.

## Database for the six web products

Use PostgreSQL 18. Provision a new local database and two separate login roles: a migration owner and a restricted runtime role. Both roles must use NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS. The migration role owns the database; grant CONNECT to both roles and revoke database access from PUBLIC. Do not run the web application as the owner or a superuser: workspace isolation depends on the restricted runtime role.

Create the ignored file .local/postgresql/.env.dev with your own values (replace every placeholder; URL-encode passwords):

~~~dotenv
DATABASE_URL=postgresql://labs_dev_runtime:YOUR_RUNTIME_PASSWORD@127.0.0.1:5432/kezuvio_labs_dev
MIGRATION_DATABASE_URL=postgresql://labs_dev_owner:YOUR_OWNER_PASSWORD@127.0.0.1:5432/kezuvio_labs_dev
DATABASE_RUNTIME_ROLE=labs_dev_runtime
LABS_ORIGIN=http://127.0.0.1:3000
~~~

Create a second ignored file .local/postgresql/.env.dev.runtime containing only DATABASE_URL and LABS_ORIGIN with the same values. Then run npm run db:migrate from the repository root. It applies the included migration history and grants the runtime role access. Run npm run build again and start the website. Alternatively supply environment variables directly to each relevant process. The website can build without a live database; the six persisted demos need a configured database to operate.

Keep both environment files private. No existing databases, credentials or user data are supplied. The data shown in demos is fictional, and payments are simulated. These applications do not claim financial, tax or regulatory compliance.

## Ledger Lite Android

Use Flutter 3.47.5 (see .flutter-version), a compatible Android SDK with API 36, and a compatible Java toolchain. From apps/ledger_lite:

~~~sh
flutter pub get
flutter gen-l10n
flutter run --flavor dev
~~~

To create a development APK use flutter build apk --debug --flavor dev. Release builds are deliberately blocked by the current Android project until release signing is implemented. Gradle wrappers, generated Dart source, localization source, lockfiles and font licenses are included. Machine-specific Android paths and signing keys are excluded.

## Source package scope

Tests, integration tests, Playwright configuration, test reports, historical delivery documents, agent settings, local toolchains, caches, builds, Git history and private environment files are excluded. Build dependencies and their original lockfiles are retained for reproducibility. Test npm scripts and test-based CI workflows are omitted.

The optional private /operations desk source is retained. Its brand utility is included because the desk uses it to locate the repository. Unit and studio verification actions require the omitted test suites and are unavailable in this source package; use the full development checkout for those actions. No private desk configuration is supplied.

For GitHub, upload the contents of this folder, including .gitignore and .env.example. With Git, run git init, git add ., and git commit locally, then connect your chosen GitHub repository. Review the files before publishing. This package has not been pushed or deployed.
